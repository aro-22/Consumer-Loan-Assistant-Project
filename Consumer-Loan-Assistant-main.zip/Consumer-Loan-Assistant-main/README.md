# Consumer-Loan-Assistant- Your Personal Assistant to calculate your loan!
A Java Project to calculate your Loan balance with given Interest rate.

This project has been developed by Rajdeep Das as a Project Intern under Suven Consultants & Technology Private Limited. (2020)
